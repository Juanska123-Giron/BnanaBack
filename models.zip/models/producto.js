import mongoose from "mongoose";
const productoSchema = mongoose.Schema({
    nombre_producto: {
        type: String,
        required: true,
        trim: true,
    },
    descripcion: {
        type: String,
        required: true,
        trim: true,
    },
    nombre: {
        type: String,
        required: true,
        trim: true,
    },
    imagenPath: {
        type: String,
        required: true,
        trim: true,
    },
    precio: {
        type: Number,
        required: true,
        trim: true,
        min: 0
    },
    stock: {
        type: Number,
        required: true,
        trim: true,
        min: 0
    },
    opinion: [{
        type: Schema.Types.ObjectID,
        ref: 'Opinion'
    }],
    proveedor:[{
        type: Schema.Types.ObjectID,
        ref: 'Proveedor',
        required: true,
    }],
    categoria: [{
        type: Schema.Types.ObjectID,
        ref: 'Categoria',
        required: true,
    }],
    oferta: [{
        type: Schema.Types.ObjectID,
        ref: 'Oferta'
    }]

},{
    timestamps: true
})
const Producto = mongoose.model("Producto", productoSchema);
export default Producto;
import mongoose from "mongoose";
const opinionSchema = mongoose.Schema({
    //para filtrar opiniones por usuario
    usuario:{
        type: Schema.Types.ObjectID,
        ref: 'Usuario'
    },
    producto:{
        type: Schema.Types.ObjectID,
        ref: 'Producto'
    },
    contenidoOpinion:{
        type: String,
        required: true,
        trim: true,
    },
},{
    timestamps: true
})
const Opinion = mongoose.model("Opinion", opinionSchema);
export default Opinion;